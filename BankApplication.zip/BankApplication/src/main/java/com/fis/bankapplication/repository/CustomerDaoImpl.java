package com.fis.bankapplication.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.fis.bankapplication.model.Customer;

@Repository
public class CustomerDaoImpl implements CustomerDao {

	@PersistenceContext
	EntityManager em;

	@Override
	public String createCustomer(Customer customer) {
		em.persist(customer);
		return "Customer created succefful !!";
	}

	@Override
	public String updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		em.merge(customer);
		return "Customer updated succefful !!";
	}

	@Override
	public String deleteCustomer(int cusId) {
		// TODO Auto-generated method stub
		em.remove(getCustomerById(cusId));
		return "Customer deleted succefful !!";
	}

	@Override
	public Customer getCustomerById(int cusId) {
		// TODO Auto-generated method stub
		return em.find(Customer.class, cusId);
	}

	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		TypedQuery<Customer> q = em.createQuery("select c from Customer c", Customer.class);

		return q.getResultList();
	}

}
