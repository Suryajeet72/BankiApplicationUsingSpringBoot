package com.fis.bankapplication.repository;

import java.util.List;

import com.fis.bankapplication.model.Customer;

public interface CustomerDao {

	// Create customer
	public abstract String createCustomer(Customer customer);

	// Update customer
	public abstract String updateCustomer(Customer customer);

	// Delete customer
	public abstract String deleteCustomer(int cusId);

	public abstract Customer getCustomerById(int cusId);

	// All Customer List
	public abstract List<Customer> getAllCustomer();
}
