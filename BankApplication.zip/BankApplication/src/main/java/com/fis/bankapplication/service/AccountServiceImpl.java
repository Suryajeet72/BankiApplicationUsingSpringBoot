package com.fis.bankapplication.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.exceptions.AccountNotFoundException;
import com.fis.bankapplication.exceptions.NotEnoughBalanceException;
import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.repository.AccountDao;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountDao accDao;

	@Override
	public String createAccount(Account account) {
		// TODO Auto-generated method stub
		return accDao.createAccount(account);
	}

	@Override
	public String updateAccount(Account account) {
		// TODO Auto-generated method stub
		return accDao.updateAccount(account);
	}

	@Override
	public String deleteAccount(long accNumber) {
		// TODO Auto-generated method stub
		return accDao.deleteAccount(accNumber);
	}

	@Override
	public Account getAccount(long accNumber) {
		// TODO Auto-generated method stub
		return accDao.getAccount(accNumber);
	}

	@Override
	public List<Account> getAccountList() {
		// TODO Auto-generated method stub
		return accDao.getAccountList();
	}

	@Override
	public String depositAccount(long accNumber, double amount) throws AccountNotFoundException {
		// TODO Auto-generated method stub
		return accDao.depositAccount(accNumber, amount);
	}

	@Override
	public String withdrawAccount(long accNumber, double amount)
			throws NotEnoughBalanceException, AccountNotFoundException {
		// TODO Auto-generated method stub
		return accDao.withdrawAccount(accNumber, amount);
	}

	@Override
	public String FundTransferAccount(long fromAccNumber, long toAccNumber, double amount)
			throws NotEnoughBalanceException, AccountNotFoundException {
		// TODO Auto-generated method stub
		return accDao.FundTransferAccount(fromAccNumber, toAccNumber, amount);
	}

}
